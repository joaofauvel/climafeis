# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['climafeis']

package_data = \
{'': ['*']}

install_requires = \
['beautifulsoup4>=4.11.1,<5.0.0',
 'numpy>=1.23.5,<2.0.0',
 'pandas>=1.5.2,<2.0.0',
 'requests>=2.28.1,<3.0.0']

entry_points = \
{'console_scripts': ['climafeis = climafeis.climascraper:main']}

setup_kwargs = {
    'name': 'climafeis',
    'version': '1.0.1',
    'description': 'Scrape climate date from clima.feis.unesp.br',
    'long_description': '# climafeis\nScript CLI em Python para scrape do banco de dados climatológicos do [Canal CLIMA](http://clima.feis.unesp.br) da [UNESP Ilha Solteira](https://www.feis.unesp.br/) com a biblioteca [Requests](https://2.python-requests.org/en/master/).  \n\n### Configuração no Windows\n1. Confira sua versão do Python em uma shell (Powershell ou CMD) com `python -V`\n1. Instale o [Python 3.4](https://www.python.org/downloads/windows/) ou superior, caso já não esteja instalado\n1. Clone esse repositório com `git clone https://github.com/joaofauvel/climafeis.git` ou [baixe o repositório](https://github.com/joaofauvel/climafeis/archive/master.zip) e extraia o conteúdo do arquivo master.zip \n1. Abra o diretório `climafeis`, recem extraído, que contém os arquivos `climascraper.py` e `requirements.txt`\n1. Instale os requisitos `pip install -r --user requirements.txt`\n\n### Configuração em uma distribuição GNU/Linux\n1. Confira sua versão do Python com `python -V`\n1. Instale o Python 3.4 ou superior e pip, caso já não estejam instalados:  \n\n    - Ubuntu e derivados `apt install python3 python3-pip`\n    - Arch e derivados `pacman -S python python-pip`\n    - Fedora `dnf install python3 python3-pip`  \n    \n1. Clone esse repositório com `git clone https://github.com/joaofauvel/climafeis.git && cd climafeis`\n1. Instale os requisitos `pip install --user -r requirements.txt`\n\n### Utilização\n    usage: climascraper.py [-h] [-U USER] [-P PW] estacao dataInicial [dataFinal]\n\n    Scrape dados diários do Canal CLIMA (http://clima.feis.unesp.br).\n\n    positional arguments:\n        estacao               Nome da estação: ILHA_SOLTEIRA, MARINOPOLIS, JUNQUEIROPOLIS, PARANAPUA,\n        IRAPURU, POPULINA, SANTA_ADELIA_PIONEIROS, SANTA_ADELIA, BONANCA, ITAPURA, DRACENA.\n        \n        dataInicial           Data inicial no formato dd/MM/YYYY (30/05/2020).\n        dataFinal             Data final no formato dd/MM/YYYY (03/05/2020). Padrão: presente dia.\n\n    optional arguments:\n        -h, --help            show this help message and exit\n        -U USER, --user USER  Usuário do Canal CLIMA. Caso seu usuário não esteja em $USER_CLIMAFEIS.\n        -P PW, --pw PW        Senha do Canal CLIMA. Caso sua senha não esteja em $PASSWD_CLIMAFEIS.\n        \n    Exemplos:\n        climascraper.py ILHA_SOLTEIRA 30/05/2020 03/06/2020             Extraí dados diários da estação de Ilha\n        Solteira dos dias 30/05/2020 ao dia 03/05/2020\n        \n        climascraper.py MARINOPOLIS 30/05/2020                          Extraí dados diários da estação de\n        Marinópolis dos dias 30/05/2020 ao presente dia\n        \n        climascraper.py ILHA_SOLTEIRA 30/05/2020 -U usuário -P senha    \n#\nAlternativamente, é recomendado a instalação dos requisitos em um ambiente virtual do Python, como [venv](https://docs.python.org/3/library/venv.html) ou [virtualenv](https://virtualenv.pypa.io/en/stable/).\n\n\n',
    'author': 'João Fauvel',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
